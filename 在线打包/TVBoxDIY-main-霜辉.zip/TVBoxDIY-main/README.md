# TVBoxDIY

Fork：https://github.com/CatVodTVOfficial/TVBoxOSC.git

源码：https://github.com/lm317379829/TVBoxOSC.git

# 说明

APK-J Build为本地爬虫-俊版，APK-T Build为本地爬虫taka版，APK-O Build为本地爬虫原版。APK-TV Build为本地爬虫Fongmi/TV版（暂时有问题，待修复）。

diy-J.sh、diy-T.sh、diy-O.sh、diy-TV.sh分别为俊版、taka版、原版自定义脚本，可自行修改apk名、背景、图标以及其他源码内容。
